# venvat
Lazy of typing long code to activate virtual environment in python? Use venvat
